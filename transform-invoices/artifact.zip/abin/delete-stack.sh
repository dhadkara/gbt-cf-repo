#!/bin/bash

aws cloudformation delete-stack \
  --stack-name test-lambda-dev 

